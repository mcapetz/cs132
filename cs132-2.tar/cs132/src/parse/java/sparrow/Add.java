package sparrow;

import IR.token.Identifier;
import sparrow.visitor.ArgRetVisitor;
import sparrow.visitor.ArgVisitor;
import sparrow.visitor.RetVisitor;
import sparrow.visitor.Visitor;

public class Add extends Instruction {
  public Identifier lhs;
  public Identifier arg1;
  public Identifier arg2;

  public Add(Identifier lhs, Identifier arg1, Identifier arg2) {
    this.lhs = lhs;
    this.arg1 = arg1;
    this.arg2 = arg2;
  }

  public void accept(Visitor v) {
    v.visit(this);
  }

  public <A> void accept(ArgVisitor<A> v, A arg) {
    v.visit(this, arg);
  }

  public <A,R> R accept(ArgRetVisitor<A,R> v, A arg) {
    return v.visit(this, arg);
  }

  public <R> R accept(RetVisitor<R> v){
    return v.visit(this);
  }

  public String toString() {
    return lhs + " = " + arg1 + " + " + arg2;
  }
}
